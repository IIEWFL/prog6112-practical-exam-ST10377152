/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package movieticketapp;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MovieTicketsGUI extends JFrame {
    private JComboBox<String> cbMovies;
    private JTextField tfNumberOfTickets;
    private JTextField tfTicketPrice;
    private JTextArea taTicketReport;
    
    public MovieTicketsGUI() {
        setTitle("MOVIE TICKETS");
        setSize(400, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridBagLayout());
        
        
        JLabel lblMovie = new JLabel("MOVIE:");
        cbMovies = new JComboBox<>(new String[] { "Napoleon", "Oppenheimer", "Damsel" });
        
        JLabel lblNumberOfTickets = new JLabel("NUMBER OF TICKETS:");
        tfNumberOfTickets = new JTextField(10);
        
        JLabel lblTicketPrice = new JLabel("TICKET PRICE:");
        tfTicketPrice = new JTextField(10);
        
        JLabel lblTicketReport = new JLabel("TICKET REPORT:");
        taTicketReport = new JTextArea(5, 20);
        taTicketReport.setEditable(false);
        
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;
        
        gbc.gridx = 0;
        gbc.gridy = 0;
        add(lblMovie, gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 0;
        add(cbMovies, gbc);
        
        gbc.gridx = 0;
        gbc.gridy = 1;
        add(lblNumberOfTickets, gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 1;
        add(tfNumberOfTickets, gbc);
        
        gbc.gridx = 0;
        gbc.gridy = 2;
        add(lblTicketPrice, gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 2;
        add(tfTicketPrice, gbc);
        
        gbc.gridx = 0;
        gbc.gridy = 3;
        add(lblTicketReport, gbc);
        
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        add(new JScrollPane(taTicketReport), gbc);
        
        
        JMenuBar menuBar = new JMenuBar();
        
        JMenu fileMenu = new JMenu("File");
        JMenuItem exitItem = new JMenuItem("Exit");
        exitItem.addActionListener(e -> System.exit(0));
        fileMenu.add(exitItem);
        
        JMenu editMenu = new JMenu("Edit");
        JMenuItem processItem = new JMenuItem("Process");
        processItem.addActionListener(new ProcessAction());
        JMenuItem clearItem = new JMenuItem("Clear");
        clearItem.addActionListener(new ClearAction());
        editMenu.add(processItem);
        editMenu.add(clearItem);
        
        menuBar.add(fileMenu);
        menuBar.add(editMenu);
        
        setJMenuBar(menuBar);
    }

    
    
private class ProcessAction implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent e) {
        String movie = (String) cbMovies.getSelectedItem();
        String ticketsStr = tfNumberOfTickets.getText();
        String priceStr = tfTicketPrice.getText();
        
        try {
            int numberOfTickets = Integer.parseInt(ticketsStr);
            double ticketPrice = Double.parseDouble(priceStr);
            
            
            if (numberOfTickets <= 0) {
                JOptionPane.showMessageDialog(MovieTicketsGUI.this, "The number of tickets must be greater than zero.", "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (ticketPrice <= 0) {
                JOptionPane.showMessageDialog(MovieTicketsGUI.this, "The ticket price must be greater than zero.", "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            
            double totalPrice = numberOfTickets * ticketPrice * 1.14;

          
            taTicketReport.setText("MOVIE NAME: " + movie + "\n" +
                    "MOVIE TICKET PRICE: R " + ticketPrice + "\n" +
                    "NUMBER OF TICKETS: " + numberOfTickets + "\n" +
                    "TOTAL TICKET PRICE: R " + String.format("%.2f", totalPrice));

           
            try (java.io.PrintWriter writer = new java.io.PrintWriter("report.txt")) {
                writer.println("MOVIE NAME: " + movie);
                writer.println("MOVIE TICKET PRICE: R " + ticketPrice);
                writer.println("NUMBER OF TICKETS: " + numberOfTickets);
                writer.println("TOTAL TICKET PRICE: R " + String.format("%.2f", totalPrice));
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(MovieTicketsGUI.this, "Please enter valid numbers for tickets and price.", "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}

    
    private class ClearAction implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            cbMovies.setSelectedIndex(0);
            tfNumberOfTickets.setText("");
            tfTicketPrice.setText("");
            taTicketReport.setText("");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new MovieTicketsGUI().setVisible(true);
        });
    }
}


