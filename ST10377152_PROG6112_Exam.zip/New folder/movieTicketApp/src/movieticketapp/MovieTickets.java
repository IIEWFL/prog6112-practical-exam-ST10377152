/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package movieticketapp;

/**
 *
 * @author lab_services_student
 */
class MovieTickets implements IMovieTickets {
    private String movieName;
    private int numTickets;
    private double ticketPrice;

    public MovieTickets(String movieName, String numTicketsStr, String ticketPriceStr) {
        this.movieName = movieName;
        try {
            this.numTickets = Integer.parseInt(numTicketsStr);
            this.ticketPrice = Double.parseDouble(ticketPriceStr);
        } catch (NumberFormatException e) {
            this.numTickets = -1;
            this.ticketPrice = -1;
        }
    }

    public double CalculateTotalTicketPrice(int numberOfTickets, double ticketPrice) {
        return numberOfTickets * ticketPrice;
    }

    public boolean ValidateData(MovieTickets movieTicketData) {
        return movieTicketData.movieName != null && !movieTicketData.movieName.isEmpty() &&
               movieTicketData.numTickets > 0 &&
               movieTicketData.ticketPrice > 0;
    }

    public boolean isValid() {
        return ValidateData(this);
    }

    public double calculateTotalPrice() {
        return CalculateTotalTicketPrice(numTickets, ticketPrice);
    }

    public int getNumTickets() {
        return numTickets;
    }

    public double getTicketPrice() {
        return ticketPrice;
    }
}
