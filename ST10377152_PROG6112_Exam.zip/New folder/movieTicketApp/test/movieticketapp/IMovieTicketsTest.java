/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package movieticketapp;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author lab_services_student
 */
public class IMovieTicketsTest {
    
    public IMovieTicketsTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of CalculateTotalTicketPrice method, of class IMovieTickets.
     */
    @Test
    public void testCalculateTotalTicketPrice() {
        System.out.println("CalculateTotalTicketPrice");
        int numberOfTickets = 3;
        double ticketPrice = 100;
        IMovieTickets instance = new IMovieTicketsImpl();
        double expResult = 342;
        double result = instance.CalculateTotalTicketPrice(numberOfTickets, ticketPrice);
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
       // fail("The test case is a prototype.");
    }

    /**
     * Test of ValidateData method, of class IMovieTickets.
     */
    @Test
    public void testValidateData() {
        System.out.println("ValidateData");
        MovieTickets movieTicketData = null;
        IMovieTickets instance = new IMovieTicketsImpl();
        boolean expResult = true;
        boolean result = instance.ValidateData(movieTicketData);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
      //  fail("The test case is a prototype.");
    }

    public class IMovieTicketsImpl implements IMovieTickets {

        public double CalculateTotalTicketPrice(int numberOfTickets, double ticketPrice) {
            return 342;
        }

        public boolean ValidateData(MovieTickets movieTicketData) {
            return true;
        }
    }
    
}
