/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package movieticketapp;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author lab_services_student
 */
public class MovieTicketsTest {
    
    public MovieTicketsTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of CalculateTotalTicketPrice method, of class MovieTickets.
     */
    @Test
    public void testCalculateTotalTicketPrice() {
        System.out.println("CalculateTotalTicketPrice");
        int numberOfTickets = 0;
        double ticketPrice = 0.0;
        MovieTickets instance = null;
        double expResult = 0.0;
        double result = instance.CalculateTotalTicketPrice(numberOfTickets, ticketPrice);
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
       // fail("The test case is a prototype.");
    }

    /**
     * Test of ValidateData method, of class MovieTickets.
     */
    @Test
    public void testValidateData() {
        System.out.println("ValidateData");
        MovieTickets movieTicketData = null;
        MovieTickets instance = null;
        boolean expResult = false;
        boolean result = instance.ValidateData(movieTicketData);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of isValid method, of class MovieTickets.
     */
    @Test
    public void testIsValid() {
        System.out.println("isValid");
        MovieTickets instance = null;
        boolean expResult = false;
        boolean result = instance.isValid();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of calculateTotalPrice method, of class MovieTickets.
     */
    @Test
    public void testCalculateTotalPrice() {
        System.out.println("calculateTotalPrice");
        MovieTickets instance = null;
        double expResult = 0.0;
        double result = instance.calculateTotalPrice();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getNumTickets method, of class MovieTickets.
     */
    @Test
    public void testGetNumTickets() {
        System.out.println("getNumTickets");
        MovieTickets instance = null;
        int expResult = 0;
        int result = instance.getNumTickets();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getTicketPrice method, of class MovieTickets.
     */
    @Test
    public void testGetTicketPrice() {
        System.out.println("getTicketPrice");
        MovieTickets instance = null;
        double expResult = 0.0;
        double result = instance.getTicketPrice();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
