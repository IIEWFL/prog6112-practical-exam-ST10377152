/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package movie;


public class MovieTickets implements IMovieTickets {
    
    @Override
    public int totalMovieSales(int[] movieTicketSales) {
        int total = 0;
        for (int sales : movieTicketSales) {
            total += sales;
        }
        return total;
    }

   
    @Override
    public String topMovie(String[] movies, int[] totalSales) {
        int maxSales = totalSales[0];
        String topMovie = movies[0];
        for (int i = 1; i < movies.length; i++) {
            if (totalSales[i] > maxSales) {
                maxSales = totalSales[i];
                topMovie = movies[i];
            }
        }
        return topMovie;
    }

    
    public static void main(String[] args) {
    
    String[] movies = {"Napoleon", "Oppenheimer"};
    String[] months = {"JAN", "FEB", "MAR"};
    int[][] sales = {
        {3000, 3500},  
        {1500, 1200},  
        {1700, 1600}   
    };

    
    MovieTickets movieTickets = new MovieTickets();

    
    int[] totalSales = new int[movies.length];
    for (int i = 0; i < movies.length; i++) {
        int[] monthlySales = {sales[0][i], sales[1][i], sales[2][i]};
        totalSales[i] = movieTickets.totalMovieSales(monthlySales);
    }

    
    System.out.println("MOVIE TICKET SALES REPORT - 2024");
    System.out.println();

    
    System.out.printf("%-12s", " ");
    for (String month : months) {
        System.out.printf("%8s", month);
    }
    System.out.println();
    System.out.println("--------------------------------------------------------");

    
    for (int i = 0; i < movies.length; i++) {
        System.out.printf("%-12s", movies[i]);
        for (int j = 0; j < sales.length; j++) {
            System.out.printf("%8d", sales[j][i]);
        }
        System.out.println();
    }
    System.out.println();

    
    for (int i = 0; i < movies.length; i++) {
        System.out.printf("Total movie ticket sales for %s: %d\n", movies[i], totalSales[i]);
    }

    
    String topPerformingMovie = movieTickets.topMovie(movies, totalSales);
    System.out.printf("Top performing movie: %s\n", topPerformingMovie);
    }
}
