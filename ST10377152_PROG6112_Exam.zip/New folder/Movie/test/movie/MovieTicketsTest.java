/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package movie;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author lab_services_student
 */
public class MovieTicketsTest {
    
    public MovieTicketsTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of totalMovieSales method, of class MovieTickets.
     */
    @Test
    public void testTotalMovieSales() {
        System.out.println("totalMovieSales");
        int[] movieTicketSales = null;
        MovieTickets instance = new MovieTickets();
        int expResult = 0;
        int result = instance.totalMovieSales(movieTicketSales);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of topMovie method, of class MovieTickets.
     */
    @Test
    public void testTopMovie() {
        System.out.println("topMovie");
        String[] movies = null;
        int[] totalSales = null;
        MovieTickets instance = new MovieTickets();
        String expResult = "";
        String result = instance.topMovie(movies, totalSales);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
       // fail("The test case is a prototype.");
    }

    /**
     * Test of main method, of class MovieTickets.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        MovieTickets.main(args);
        // TODO review the generated test code and remove the default call to fail.
      //  fail("The test case is a prototype.");
    }
    
}
