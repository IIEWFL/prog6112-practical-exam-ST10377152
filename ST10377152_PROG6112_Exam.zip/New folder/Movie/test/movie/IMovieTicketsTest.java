/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package movie;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author lab_services_student
 */
public class IMovieTicketsTest {
    
    public IMovieTicketsTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of totalMovieSales method, of class IMovieTickets.
     */
    @Test
    public void testTotalMovieSales() {
        System.out.println("totalMovieSales");
        int[] movieTicketSales = {3000, 1500, 1700};
        int[] napoleonSales = {3000, 1500, 1700};
        int[] oppenheimerSales = {3500, 1200, 1600};
        IMovieTickets instance = new IMovieTicketsImpl();
        int expResult = 0;
        int result = instance.totalMovieSales(movieTicketSales);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of topMovie method, of class IMovieTickets.
     */
    @Test
    public void testTopMovie() {
        System.out.println("topMovie");
        String[] movies = null;
        int[] totalSales = null;
        IMovieTickets instance = new IMovieTicketsImpl();
        String expResult = "";
        String result = instance.topMovie(movies, totalSales);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
       // fail("The test case is a prototype.");
    }

    public class IMovieTicketsImpl implements IMovieTickets {

        public int totalMovieSales(int[] movieTicketSales) {
            return 0;
        }

        public String topMovie(String[] movies, int[] totalSales) {
            return "";
        }
    }
    
}
